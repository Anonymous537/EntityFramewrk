﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Album album;
        //Entities1 entities;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                album = new Album();
                album.AlbumID = Convert.ToInt32(txtbox1.Text);
                album.Name = txtbox2.Text;
                album.Genre = txtbox3.Text;
                album.Year = Convert.ToDateTime(datepicker1.Text);
                album.Price = Convert.ToDecimal(txtbox4.Text);

                Entities1 entities = new Entities1();
                entities.Albums.Add(album);
                entities.SaveChanges();

                MessageBox.Show("Added Album Successfully");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Entities1 entities = new Entities1();
                datagrid1.ItemsSource = entities.Albums.ToList();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
