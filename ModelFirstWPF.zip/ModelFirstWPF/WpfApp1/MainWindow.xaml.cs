﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BloggingModel1Container container;
        public MainWindow()
        {
            InitializeComponent();
            container = new BloggingModel1Container();
        }
        
private void btn1_Click(object sender, RoutedEventArgs e)
        {
            Blog[] blogs = new Blog[]
                {
                    new Blog {Name="Blog1",URL="www.blog1.com"},
                    new Blog {Name="Blog2", URL="www.blog2.com"},
                    new Blog {Name="Blog3",URL="www.blog3.com"}
                };
            container.Blogs.AddRange(blogs);
            container.SaveChanges();
            MessageBox.Show("Blog info added successfully");
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            datagrid1.ItemsSource = container.Blogs.ToList();
        }
    }
}
